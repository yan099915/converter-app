// defines router
const psdRouter = require("./psdroutes");
const ytRouter = require("./ytroutes");
const iconRouter = require("./iconroutes");

// export router for server.js
module.exports = {
  psdRouter,
  ytRouter,
  iconRouter,
};
