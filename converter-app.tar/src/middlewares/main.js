require("dotenv").config();

module.exports = {
  validateBody: (req, res, next) => {},
};
